from controller import Robot, Camera, Motor
import cv2
import numpy as np

# --------------------------------------------------------------------------------
# detect_and_avoid_obstacle: Vision-based obstacle detection
# --------------------------------------------------------------------------------
def detect_and_avoid_obstacle(camera, camera_width, max_speed):
    log_msgs = []
    obstacle_found = False
    direction = None

    gray = cv2.cvtColor(camera, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    _, thresh = cv2.threshold(blur, 60, 255, cv2.THRESH_BINARY_INV)

    cv2.imshow("Thresholded Image", thresh)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    left_motor = max_speed
    right_motor = max_speed
    img_center = camera_width // 2
    MIN_CONTOUR_AREA = 95000

    for cnt in contours:
        area = cv2.contourArea(cnt)
        if area < MIN_CONTOUR_AREA:
            continue

        x, y, w, h = cv2.boundingRect(cnt)
        obj_center = x + (w // 2)

        cv2.rectangle(camera, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(camera, "Obstacle", (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

        log_msgs.append(f"Vision Obstacle @ x={x},y={y},w={w},h={h},area={area:.1f}")

        if obj_center < img_center - 100:
            left_motor, right_motor = 0.2 * max_speed, 0.5 * max_speed
            log_msgs.append("Turning RIGHT (vision obstacle left)")
            direction = "RIGHT"
        elif obj_center > img_center + 100:
            left_motor, right_motor = 0.3 * max_speed, 0.2 * max_speed
            log_msgs.append("Turning LEFT (vision obstacle right)")
            direction = "LEFT"
        else:
            left_motor, right_motor = -0.5 * max_speed, 0.5 * max_speed
            log_msgs.append("Rotating (vision obstacle center)")
            direction = "CENTER"

        obstacle_found = True
        break

    return left_motor, right_motor, log_msgs, camera, obstacle_found, direction

# --------------------------------------------------------------------------------
# Main Webots Controller Logic
# --------------------------------------------------------------------------------
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Device Initialization
camera = robot.getDevice('camera')
camera.enable(timestep)

left_motor = robot.getDevice('left_motor')
right_motor = robot.getDevice('right_motor')

# Set motors to velocity control mode
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

max_speed = 6.28  # Adjust according to your motor specs

# Main control loop
while robot.step(timestep) != -1:
    # Get camera image and convert to OpenCV format
    image = camera.getImage()
    width = camera.getWidth()
    height = camera.getHeight()

    img_array = np.frombuffer(image, np.uint8).reshape((height, width, 4))
    img_bgr = cv2.cvtColor(img_array, cv2.COLOR_BGRA2BGR)

    # Detect and avoid obstacle
    left_speed, right_speed, logs, annotated_img, found, direction = detect_and_avoid_obstacle(
        img_bgr, width, max_speed
    )

    # Set speeds
    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)

    # Optional: Print log messages
    for msg in logs:
        print(msg)

    # Optional: save or display image (for debugging)
    cv2.imshow("Camera", annotated_img)
    cv2.waitKey(1)
